# Demo (示範影片)

### 2024-03-17
(2024-03-31) 為什麼我太太搶到8張(他就一個帳號+一台破電腦)？

https://youtu.be/d3JxIk4hLsw

### 2024-03-13
KKTIX 無視窗搶票

https://youtu.be/j9k7-2g-X3o

### 2024-03-09: 
增加瀏覽器視窗大小的設定值, 方便視窗多開 

https://youtu.be/zPgP43w-ceg

### 2024-03-08 
KKIX 加購粉絲福利

https://youtu.be/Hc2wW_sWiAo

### 2024-03-06: 
(2024-03-24) IU 演唱會沒搶到，沒搶到票建議多刷10~20分鐘

https://youtu.be/6R3tGCZ_s6c

### 2024-03-22
MaxBot 售票系統架構猜測與搶票建議

https://youtu.be/alpy9HX6aRw

### 2024-03-04: 
(2024-03-16) KKTIX 的 Golden Wave in Taiwan 搶票心得

https://youtu.be/OZauGhoj4xU 
* 前面都癈話，可以直接快轉到最後30秒。

### 2024-03-02: 
一直問KKTIX清票了沒, 解決KKTIX不定期清票

https://youtu.be/4FTzfe1ZC8o

### 2024-02-02: 
KKTIX 定時啟動+帳號多開

https://youtu.be/eETZTajxBnY

### 2024-02-01: 
搶遠大Lisa票,沒搶到 (2024-02-24)

https://youtu.be/G8MchGUkbzw

### 2024-01-18: 
調整KKTIX驗證問題的輸入

https://youtu.be/R65wvmbCe2A

### 2024-01-17: 
調整ibon驗證問題的輸入

https://youtu.be/z3mM_Ljui2U

### 2024-01-16: 
只使用 chrome 擴充功能輸入驗證碼

https://youtu.be/8RtmfknXdGk

### 2024-01-15: 
MaxBot Plus 1.0.6 擴充功能 for ticktmaster.sg

https://youtu.be/V8S_E7ayAGU

### 2024-01-15: 
增加關鍵字對狀態做開關的切換

https://youtu.be/u3YQCZZu6kE

### 2024-01-12:
MaxBot 自動重啟瀏覽器 (遠大刷太久會Out Of Memory)

https://youtu.be/mp6pYgniaPU

### 2024-01-10:
MaxBot Plus 擴充功能 刷hkticketing

https://youtu.be/zOzFYJsqWME

### 2024-01-08:
遠大清票延遲重刷

https://youtu.be/j6DlV4BFCuM

### 2024-01-06:
MaxBot擴充功能在iNDIEVOX選取套票

https://youtu.be/WLukzMTbNR8

### 2024-01-05: 
MaxBot Plus 擴充功能支援驗證碼輸入

https://youtu.be/nRBr19u6cHY

### 2024-01-02: 
MaxBot Plus 擴充功能在 ibon 輸入張數

https://youtu.be/kb7hjzqbVV8

### 2024-01-01: 
MaxBot Plus 擴充功能 刷cityline

https://youtu.be/rRl_EETv_b0

### 2023-12-27: 
KKTIX 支援用擴充功能搶票

https://youtu.be/F1lw7q9v9x8

### 2023-12-21: 
擴充工具自動刷新遠大售票活動

https://youtu.be/_9ELX4k9EiU

### 2023-12-20: 
增加 chrome 擴充功能

https://youtu.be/5urnbPEDG50

### 2023-12-14: 
遠大支援自動登入後網址切為實際搶票頁面

https://youtu.be/U6JlElHiPuo

### 2023-12-10: 
KKTIX 搶車票

https://youtu.be/csUJ6kRSynY

### 2023-12-08: 
遠大支援購票目錄下單一項目時自動填入張數

https://youtu.be/cuVwUG8IYR4

### 2023-12-07: 
遠大支援購票目錄下非第一項目的票券

https://youtu.be/wuxQTVumOP0

### 2023-12-06: 
遠大售票尚未開賣更快地刷新

https://youtu.be/ls_IU81Kn6k

### 2023-12-04: 
支援udn售票的快速購票模式

https://youtu.be/qbkMnOuB9z8

### 2023-12-07: 
「2023年第30屆亞洲棒球錦標賽」搶票分享(有搶到)

https://youtu.be/8M5LwSZNDX0

### 2023-11-06: 
在虛擬主機環境下搶票

https://youtu.be/-LUt7Au03ps

### 2023-11-04: 
支援新的排序方式：中間選項(center)

ticketmaster 支援區域自動點擊

https://youtu.be/9fqiQHJmIeM

### 2023-11-04: 
FamiTicket 填入優惠驗證序號

https://youtu.be/i3BycvHMgPY

### 2023-10-20: 
FamiTicket 支援新購票頁面

https://youtu.be/EWfdK29P-aw

### 2023-10-13: 
遠大,自動按"未結帳訂單"的確定

https://youtu.be/da7W2pCEYxg

### 2023-10-12: 
遠大,自動按"我已經閱讀並同意"/遇到輸入框停止.

https://youtu.be/VQekrSB9Ayk

### 2023-10-11: 
遠大,自動按"好玩其他活動"

https://youtu.be/-CazfZFvoh0

### 2023-10-10: 
支援設定代理伺服器(Proxy), 還沒支援 account:password 模式.

https://youtu.be/sao9k_PnC0w

### 2023-07-09:
日期關鍵字支援多組與順位

https://youtu.be/IgX4viS1Eq0

### 2023-07-06:
寬宏檢查剩餘票數/日期關鍵字做排除

https://youtu.be/nV34M4JysBg

### 2023-07-04:
ticketmaster 支援無區域地圖的購票表單

https://youtu.be/Jj2vca2kNZE

### 2023-06-27:
遠大支援第二種購票的網頁框架

https://youtu.be/tveqM0-cmCc

### 2023-06-26:
遠大驗證碼自動重試

https://youtu.be/2qC1HBMbAUU

### 2023-06-25:
hkticketing 本地端字典檔自動輸入信用卡前6碼

https://youtu.be/BlIRYkd296Y

### 2023-06-22:
indievox 支援「區域關鍵字」用在票種與數量的頁面

https://youtu.be/rnYr5CSovGE

### 2023-06-18:
KKTIX/ibon/拓元 合併本地字典與線上字典檔

https://youtu.be/LnJbZokIyOY

### 2023-06-17:
ibon 檢示與輸入驗證問題與答案/線上JSON代管

https://youtu.be/ues16dHB7UI

### 2023-06-16:
允許多位線上槍手的答案支援/在App中顯示與輸入驗證問題與答案

https://youtu.be/7kEyZI3Xark

### 2023-06-15:
從網路取得驗證問題答案清單

https://youtu.be/wHCNsyud54U

### 2023-06-14:
支援brave瀏覽器/刷新時隨機延遲

https://youtu.be/QMX6Fo0fRfo

### 2023-06-06:
寬宏-允許不連續座位/針對驗證碼錯誤時做處理

https://youtu.be/vCadxG-7yhk

### 2023-05-27:
ibon 在自動選擇區域時, 支援檢查剩餘張數要大於等於要搶的張數. 

https://youtu.be/gsAXIRI7uj0

### 2023-05-23:
ibon 允許不連續座位

https://youtu.be/A9EU7vgWBiQ

### 2023-05-22:
遠大售票系統

https://youtu.be/mlc7_5O_nwg

### 2023-05-22:
年代售票系統 / 新的關鍵字格式

https://youtu.be/gJo8rGQsyzY

### 2023-05-22:
HKTicketing 快達票

https://youtu.be/U-Rx5RIMFOg

### 2023-04-24:
優化KKTIX 推論驗證問題/示範多開.

https://youtu.be/Wn1qLz-Re8c

### 2023-03-27:
kktix無票時刷新頁面,暫停搶票程式

https://www.youtube.com/watch?v=4trNmMDntwM

### 2023-03-02:
澳門銀河購票無延遲

https://youtu.be/mFxzzWU4ksU

### 2023-02-25:
ibon只搶限定的票價

https://youtu.be/ZtnAh-VY5qs

### 2023-02-25:
透過cookie的ibonqware登入ibon

https://youtu.be/QnaCRQjAlng

### 2023-02-24:
KKTix，多設定檔管理

https://youtu.be/QgLAHkJbhqQ

### 2023-02-22:
拓元，透過 cookie SID登入

https://youtu.be/fkx0HGqTpTg

### 2023-02-19:
拓元，從驗證問題猜測答案

https://youtu.be/5rOi56dNEs8

### 2023-02-16:
拓元，從字典檔輸入驗證答案

https://youtu.be/TuacFXzuvlM

### 2023-02-10:
自動登入/區域關鍵字增加開關

https://youtu.be/Ft2WIWglZ5E

### 2023-02-08:
Edge瀏覽器WebDriver下載與設定

https://youtu.be/TzbBAEVVtoM

### 2023-02-08:
重新支援hkticketing

https://youtu.be/pk-7gIztB2Y

### 2023-02-03:
優化KKTIX 推論驗證問題

https://youtu.be/I4OOTlgpsOA

### 2023-01-29:
支援galaxymacau(澳門銀河)

https://youtu.be/yt7SkRvBujU

### 2023-01-22:
hkticketing(快達票)

https://youtu.be/pZJlcMjayco

### 2023-01-14:
優化KKTIX "演出日期"的驗證問題

https://youtu.be/ChmGZMaV2w8

### 2023-01-14:
indievox 猜測驗證碼 / 視窗多開

https://youtu.be/O84H1wNO2_w

### 2023-01-11:
tixcraft 自動輸入驗證碼

https://youtu.be/t1k0CvmBNhQ (macOS)

https://youtu.be/6JdEdcW8LtY (Windows)

### 2023-01-07:
輸入驗證問題答案為"同意"

https://youtu.be/UgemzrsCC-M

### 2023-01-05:
不等 cityline 的 10秒，直接重導網址

https://youtu.be/wGU4GJJ-ufw

### 2023-01-02:
KKITX自動猜測驗證問題

https://youtu.be/7CtSVBGwx9I (macOS)

https://youtu.be/BcyfkXF2AJU (Windows)

### 2023-01-02:
支援 ibon 售票系統

https://youtu.be/VaYc5GKk1Rk

### 2023-01-01:
支援新版本的 cityline

https://youtu.be/R5LY7pJgAzI (macOS)

https://youtu.be/2UNaAEjysvk (Windows)

### 2023-01-01:
支援新版本的 urbtix

https://youtu.be/_6jxqVC39x8 (macOS)

https://youtu.be/PWKBZ8aG9Rg (Windows)

### 2022-11-24:
KKTix 支援避開「剩餘 1」的區域的功能。增加關鍵字#2 的欄位。

https://youtu.be/nupJlwRNOIA

### 2022-11-18:
增加 adblock plus 的功能。輸入驗證碼時，會播放音效，在清票時很有幫功，不需要一直緊盯著螢幕。

https://youtu.be/Atujl8MPHQI

### 2022-11-06:
優化kktix/拓元的關鍵字比對，修改為不區分逗號、空格與大小寫。

https://youtu.be/v9mI02kVaNw

### 2022-10-22:
優化kktix/拓元的價格的關鍵字比對。

https://youtu.be/NZzQcDQkrNI

### 2022-10-21:
針對kktix 活動增加第二個關鍵字欄位。

https://youtu.be/x-OdqvUupiA

### 2022-01-26:
FamiTicket

https://youtu.be/ZV-G91FHVik
